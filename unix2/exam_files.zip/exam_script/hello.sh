#!/bin/bash

echo "n22018 $(date)"

